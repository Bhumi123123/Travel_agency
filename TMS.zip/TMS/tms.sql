-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2024 at 07:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `LPassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Username`, `LPassword`) VALUES
(1, 'Bhumika', 'Bhumi@123');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_ID` int(11) NOT NULL,
  `EName` varchar(50) NOT NULL,
  `Position` varchar(50) NOT NULL,
  `Admin_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_ID`, `EName`, `Position`, `Admin_ID`) VALUES
(201, 'Dimple', 'Manager', 1),
(202, 'Madan', 'Driver', 1),
(203, 'Darshan', 'Driver', 1),
(204, 'Bhumika', 'Manager', 1),
(205, 'Kiran', 'Driver', 1),
(206, 'Anusha', 'Manager', 1),
(207, 'Iqra', 'Manager', 1);

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `LFrom` varchar(100) NOT NULL,
  `To_` varchar(50) NOT NULL,
  `Transport_ID` int(11) NOT NULL,
  `vehicle_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`LFrom`, `To_`, `Transport_ID`, `vehicle_ID`) VALUES
('Shimoga', 'TRIPURA', 105, 1),
('AGRA', 'UTTAR PRADESH', 104, 2),
('AHMEDABAD', 'GUJARAT', 104, 3),
('kadur', 'badravathi', 101, 4),
('Bangalore', 'Bangalore Urban', 106, 5);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `Schedule_ID` int(11) NOT NULL,
  `Transport_ID` int(11) NOT NULL,
  `source_Time` time NOT NULL,
  `destination_Time` time NOT NULL,
  `Employee_ID` int(11) NOT NULL,
  `SDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`Schedule_ID`, `Transport_ID`, `source_Time`, `destination_Time`, `Employee_ID`, `SDate`) VALUES
(301, 101, '12:39:00', '05:00:13', 201, '2024-03-05'),
(302, 102, '15:27:00', '00:00:16', 201, '2024-03-06'),
(303, 105, '02:13:00', '00:00:15', 204, '2024-03-17');

-- --------------------------------------------------------

--
-- Table structure for table `transport`
--

CREATE TABLE `transport` (
  `Transport_ID` int(11) NOT NULL,
  `TName` varchar(50) NOT NULL,
  `TType` varchar(50) NOT NULL,
  `TNo_of_vehicles` int(11) NOT NULL,
  `Capacity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transport`
--

INSERT INTO `transport` (`Transport_ID`, `TName`, `TType`, `TNo_of_vehicles`, `Capacity`) VALUES
(101, 'Bus', 'Single-decker', 8, '20 seats'),
(102, 'Bus', 'Double-decker', 5, '90 seats'),
(103, 'Bus', 'Sleeper coach', 6, '22 seats'),
(104, 'Bus', 'Mini Bus', 10, '25 seats'),
(105, 'Bus', 'Volvo', 7, '50 seats'),
(106, 'Bus', 'Sleeper coach A/C', 2, '20 seats'),
(107, 'Bus', 'Express A/C', 6, '35 seats');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_ID`),
  ADD KEY `Admin_ID` (`Admin_ID`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`vehicle_ID`),
  ADD KEY `Transport_ID` (`Transport_ID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`Schedule_ID`),
  ADD KEY `Transport_ID` (`Transport_ID`),
  ADD KEY `Employee_ID` (`Employee_ID`);

--
-- Indexes for table `transport`
--
ALTER TABLE `transport`
  ADD PRIMARY KEY (`Transport_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`Admin_ID`) REFERENCES `admin` (`Admin_ID`) ON DELETE CASCADE;

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_1` FOREIGN KEY (`Transport_ID`) REFERENCES `transport` (`Transport_ID`) ON DELETE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`Transport_ID`) REFERENCES `transport` (`Transport_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `schedule_ibfk_2` FOREIGN KEY (`Employee_ID`) REFERENCES `employee` (`Employee_ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
